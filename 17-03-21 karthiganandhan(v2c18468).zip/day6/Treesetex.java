

import java.util.*;  
class Treesetex{  
 public static void main(String args[]){  

  TreeSet<String> al=new TreeSet<String>();  
  al.add("karthi");  
  al.add("surya");  
  al.add("nandha");  
  al.add("david");  
  Iterator<String> itr=al.iterator();  
  while(itr.hasNext()){  
   System.out.println(itr.next());  }
   System.out.println("Highest Value: "+al.pollFirst());  
   System.out.println("Lowest Value: "+al.pollLast());  
  
   Iterator<String> itr1=al.iterator();  
   while(itr1.hasNext()){  
    System.out.println(itr1.next()); 
   }
    
    System.out.println("Reverse Set: "+al.descendingSet());  
    
    System.out.println("Head Set: "+al.headSet("karthi", true));  
     
     
  }  
 }  
 
