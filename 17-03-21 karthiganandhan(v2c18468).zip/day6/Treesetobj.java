import java.util.*; 
class stud{ 
    
    private int marks; 
    private String name;
    private String grade;
    
   
    
	public stud(int marks, String name, String grade) {
		
		this.marks = marks;
		this.name = name;
		this.grade = grade;
	}
	public String getName()  
    { 
        return name; 
    } 
    public void setName(String name) 
    { 
        this.name= name; 
    } 
      
    public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
    public int getMarks()  
    { 
        return marks; 
    } 
      
}
class myMarksComparator implements Comparator<stud> 
{ 
    
    public int compare(stud s1, stud s2)  
    { 
        return s1.getMarks()-s2.getMarks(); 
    } 
} 
  
class myNameComparator implements Comparator<stud> 
{ 
    public int compare(stud s1, stud s2) 
    { 
        return s1.getName().compareTo(s2.getName()); 
    } 
} 
  
class myGradeComparator implements Comparator<stud> 
{ 
    public int compare(stud s1, stud s2) 
    { 
        return s1.getGrade().compareTo(s2.getGrade()); 
    } 
} 
class Treesetobj { 
  
    public static void main (String[] args){ 
          
       TreeSet<stud> set = new TreeSet<stud>(new myMarksComparator()); 
          
        set.add(new stud(450,"surya","A")); 
        set.add(new stud(341,"david","B")); 
        set.add(new stud(134,"karthi","F")); 
        set.add(new stud(590,"nandha","S")); 
          
        System.out.println("increasing Order with the Marks"); 
        for(stud ele: set) 
        { 
            System.out.print(ele.getName()+" "+ele.getMarks()+" "+ele.getGrade()); 
            System.out.println(); 
        } 
          
          
        TreeSet<stud> mrks= new TreeSet<stud>(new myNameComparator()); 
          
        mrks.add(new stud(450,"surya","A")); 
        mrks.add(new stud(341,"david","B")); 
        mrks.add(new stud(134,"karthi","F")); 
        mrks.add(new stud(590,"nandha","S")); 
          
        System.out.println(); 
        System.out.println("increasing Order with the name"); 
        for(stud ele1 : mrks)  
        { 
        	 System.out.print(ele1.getName()+" "+ele1.getMarks()+" "+ele1.getGrade()); 
            System.out.println(); 
        } 
        TreeSet<stud> grd= new TreeSet<stud>(new myGradeComparator()); 
        
        grd.add(new stud(450,"surya","A")); 
        grd.add(new stud(341,"david","B")); 
        grd.add(new stud(134,"karthi","F")); 
        grd.add(new stud(590,"nandha","S")); 
          
        System.out.println(); 
        System.out.println("increasing Order with the grade"); 
        for(stud ele2 : grd)  
        { 
        	 System.out.print(ele2.getName()+" "+ele2.getMarks()+" "+ele2.getGrade()); 
            System.out.println(); 
        } 
  
    } 
} 