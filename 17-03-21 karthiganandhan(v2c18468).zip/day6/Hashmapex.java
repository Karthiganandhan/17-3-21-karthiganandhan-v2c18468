import java.util.*;
import java.util.Map.Entry;  
class Hashmapex{  
 public static void main(String args[]){  
   HashMap<Integer,String> obj=new HashMap<Integer,String>();    
      obj.put(100,"java");    
      obj.put(101,"python");    
     obj.put(102,"C");   
      System.out.println("Initial list of elements:");  
     for (Iterator<Entry<Integer, String>> iterator = obj.entrySet().iterator(); iterator.hasNext();) {
		Entry<Integer, String> e = iterator.next();
		System.out.println(e.getKey()+" "+e.getValue());
	}  
     System.out.println("Updated list of elements:");  
     obj.replace(102, "c#");  
     for (Iterator<Entry<Integer, String>> iterator = obj.entrySet().iterator(); iterator.hasNext();) {
    	 Entry<Integer, String> e = iterator.next();
 		System.out.println(e.getKey()+" "+e.getValue());
	}  
     System.out.println("Updated list of elements:");  
     obj.replace(101, "python", "js");  
     for (Iterator<Entry<Integer, String>> iterator = obj.entrySet().iterator(); iterator.hasNext();) {
    	 Entry<Integer, String> e = iterator.next();
 		System.out.println(e.getKey()+" "+e.getValue());
	}   
     System.out.println("Updated list of elements:");  
     obj.replaceAll((s,v) -> "HTML5");  
     for (Iterator<Entry<Integer, String>> iterator = obj.entrySet().iterator(); iterator.hasNext();) {
    	 Entry<Integer, String> e = iterator.next();
 		System.out.println(e.getKey()+" "+e.getValue());
	}  
 }  
}  