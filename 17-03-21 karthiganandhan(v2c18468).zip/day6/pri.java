import java.util.Queue;
import java.util.PriorityQueue;

class pri {

    public static void main(String[] args) {
        // Creating Queue using the PriorityQueue class
       PriorityQueue<Integer> numbers = new PriorityQueue<>();

        // offer elements to the Queue
       numbers.offer(5);
        numbers.offer(1) ;
        numbers.offer(2);
        numbers.offer(1);
        numbers.offer(3) ;
        numbers.offer(8);
        System.out.println("Queue: " + numbers);
        Queue<Integer> numbers1 = new PriorityQueue<>();

        numbers1.add(5);
        numbers1.add(1) ;
        numbers1.add(2);
        numbers1.add(1);
        numbers1.add(3) ;
        numbers1.add(8);

        System.out.println("Queue: " + numbers1);
        // Access elements of the Queue
        int accessedNumber = numbers.peek();
        System.out.println("Accessed Element: " + accessedNumber);

        // Remove elements from the Queue
        int removedNumber = numbers.poll();
        System.out.println("Removed Element: " + removedNumber);

        System.out.println("Updated Queue: " + numbers);
        
        
        
        int accessedNumber1 = numbers1.peek();
        System.out.println("Accessed Element: " + accessedNumber1);

        // Remove elements from the Queue
        
       
       
        System.out.println("Updated Queue: " + numbers1);
        numbers1.clear();
        int removedNumber2 = numbers1.remove();
        System.out.println("Removed Element by remove: " + removedNumber2);

        System.out.println("Updated Queue: " + numbers1);
        
        
        numbers.clear();
        int removedNumber1 = numbers.poll();
        System.out.println("Removed Element by remove: " + removedNumber1);

        System.out.println("Updated Queue: " + numbers);
    }
}